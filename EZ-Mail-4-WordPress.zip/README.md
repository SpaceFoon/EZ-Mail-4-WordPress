# EZ-Mail-4-WordPress
 No bloat and easy to config. Also send from email based on email subject.
